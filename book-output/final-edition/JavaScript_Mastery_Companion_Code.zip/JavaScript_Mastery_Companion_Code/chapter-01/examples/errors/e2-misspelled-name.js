consol.log('Hello, JavaScript!');
