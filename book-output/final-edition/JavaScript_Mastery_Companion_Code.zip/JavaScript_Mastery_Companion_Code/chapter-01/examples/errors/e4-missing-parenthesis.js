console.log('Hello, JavaScript!';
