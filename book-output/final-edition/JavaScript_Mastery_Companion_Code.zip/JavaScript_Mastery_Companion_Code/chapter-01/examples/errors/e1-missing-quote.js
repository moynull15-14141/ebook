console.log('Hello, JavaScript!);
