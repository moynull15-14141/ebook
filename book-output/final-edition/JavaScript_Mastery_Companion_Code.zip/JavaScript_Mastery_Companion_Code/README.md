# JavaScript Mastery — শূন্য থেকে প্রফেশনাল: Companion Code

লেখক: Moynul Hasan

এই Archive-এ বইয়ের ৩০টি অধ্যায়ের সব Project ও উদাহরণ আছে। বইয়ে যে Path দেখানো (যেমন `project/travel-live/src/gateway.mjs` বা `examples/02-sse-basic.mjs`), তা সংশ্লিষ্ট `chapter-NN/` Folder থেকে হুবহু একই। উদাহরণের File-গুলো `../project/...` দিয়ে Project-এর Code Import করে, তাই Folder-এর গঠন বদলাবেন না।

## প্রয়োজন

| বিষয় | প্রয়োজন |
| --- | --- |
| Node.js | 22.5 বা নতুন (অধ্যায় ২৬, ২৭-এর Outbox, ২৯ ও ৩০-এ `node:sqlite`); অন্য অধ্যায় 20+ |
| Browser | আধুনিক Chrome, Edge বা Firefox; Browser Project Local HTTP Server থেকে খুলুন |
| TypeScript | অধ্যায় ২৪-এ প্রয়োজন, অধ্যায় ৩০-এ ঐচ্ছিক (`npm install` করলে আসে) |
| Database | আলাদা Server লাগে না (SQLite Node.js-এর অন্তর্নির্মিত); অধ্যায় ২৬-এর PostgreSQL Adapter ঐচ্ছিক, চালানো হয়নি |
| বাইরের npm Package | শুধু: অধ্যায় ২৪ (typescript, @types/node), ২৫ (express), ২৭ (ws), ৩০ (ঐচ্ছিক typescript, @types/node) |
| Docker | ঐচ্ছিক (অধ্যায় ২৮); যাচাইয়ে Docker Build চালানো হয়নি |

## চালানো

1. সংশ্লিষ্ট `chapter-NN/project/<নাম>/` Folder-এ যান এবং সেখানকার README পড়ুন।
2. `package.json`-এ Dependency থাকলে আগে `npm install`।
3. Test: `npm test` (বা `node --test`)। Browser Project: Folder-এ `npx serve` বা `python -m http.server 8000` চালিয়ে Browser-এ খুলুন।

## Project-এর তালিকা

| অধ্যায় | Folder | npm Package |
| --- | --- | --- |
| 1 — JavaScript-এর জগতে প্রথম পদক্ষেপ | `chapter-01/project/interactive-greeting-app/` | — |
| 2 — Variables, Data Types এবং Memory | `chapter-02/project/student-result-calculator/` | — |
| 3 — Operators এবং Decision Making | `chapter-03/project/shopping-discount-calculator/` | — |
| 4 — Loops এবং Iteration | `chapter-04/project/cart-analyzer/` | — |
| 5 — Functions এবং Scope | `chapter-05/project/invoice-calculator/` | — |
| 6 — Arrays এবং Data Processing | `chapter-06/project/inventory-dashboard/` | — |
| 7 — Objects: Properties, Methods, Destructuring এবং Data Modeling | `chapter-07/project/student-management/` | — |
| 8 — Strings এবং Modern Text Processing | `chapter-08/project/content-search-utility/` | — |
| 9 — DOM Manipulation, Events এবং Interactive Web Applications | `chapter-09/project/task-manager/` | — |
| 10 — Asynchronous JavaScript: Callbacks, Promises, async/await এবং Event Loop | `chapter-10/project/user-directory-explorer/` | — |
| 11 — Error Handling, Debugging এবং Defensive Programming | `chapter-11/project/order-validation/` | — |
| 12 — Modern JavaScript (ES6+), Modules এবং Clean Code Practices | `chapter-12/project/modular-shopping-cart/` | — |
| 13 — Object-Oriented Programming (OOP): Classes, Prototypes, Inheritance এবং Encapsulation | `chapter-13/project/booking-lab/` | — |
| 14 — Advanced Functions, Closures, Higher-Order Patterns এবং Functional Programming | `chapter-14/project/sales-function-lab/` | — |
| 15 — JavaScript Browser APIs, Web Storage, Fetch, URL এবং Real-World Browser Applications | `chapter-15/project/bookmark-vault/` | — |
| 16 — JavaScript Error Handling, Debugging, Testing এবং Software Reliability | `chapter-16/project/booking-guard/` | — |
| 17 — JavaScript Regular Expressions, Advanced Validation এবং Secure Input Processing | `chapter-17/project/form-shield/` | — |
| 18 — Functional Programming, Immutability এবং Advanced Data Transformation | `chapter-18/project/ledger-flow/` | — |
| 19 — JavaScript Performance Optimization, Memory Management এবং Web Application Efficiency | `chapter-19/project/perf-lab/` | — |
| 20 — JavaScript Security Fundamentals, Web Application Security এবং Secure Coding Practices | `chapter-20/project/secure-trip/` | — |
| 21 — JavaScript Design Patterns, Software Architecture এবং Scalable Application Structure | `chapter-21/project/visa-flow/` | — |
| 22 — JavaScript Testing Mastery: Unit Testing, Integration Testing, Mocking, TDD এবং E2E | `chapter-22/project/currency-desk/` | — |
| 23 — JavaScript Performance Optimization, Memory Management, Profiling এবং Web Application Performance | `chapter-23/project/travel-search/` | — |
| 24 — JavaScript থেকে TypeScript: Static Typing, Type Safety এবং Professional Development Workflow | `chapter-24/project/typesafe-claims/` | @types/node, typescript |
| 25 — JavaScript Backend Development with Node.js: REST APIs, Express, Databases, Authentication এবং Production Architecture | `chapter-25/project/lead-desk/` | express |
| 26 — Advanced Database Integration, ORM, Query Optimization এবং Scalable Data Architecture | `chapter-26/project/travel-data/` | — |
| 27 — Real-Time JavaScript Applications | `chapter-27/project/travel-live/` | ws |
| 28 — Professional JavaScript Deployment, Docker, CI/CD, Cloud Infrastructure এবং Production Monitoring | `chapter-28/project/deploy-ready/` | — |
| 29 — Advanced JavaScript System Design, Microservices, Distributed Systems এবং Enterprise Architecture | `chapter-29/project/travel-saga/` | — |
| 30 — JavaScript Professional Mastery, Full-Stack Capstone এবং Career Roadmap | `chapter-30/project/travel-master-pro/` | @types/node, typescript |

## যাচাই-পরিবেশ

সব Code Windows 10, Node.js 22.16.0 ও Chrome 155-এ চালিয়ে দেখা হয়েছে। চালানো হয়নি: PostgreSQL ও Prisma (অধ্যায় ২৬), Socket.IO ও Redis (অধ্যায় ২৭), Docker Build ও GitHub Actions (অধ্যায় ২৮), কোনো আসল Payment Gateway (অধ্যায় ২৯, ৩০)। বিস্তারিত বইয়ের পরিশিষ্ট গ-তে।

## License

[লেখক নির্ধারণ করবেন — এখনো নির্ধারিত হয়নি]

এই Code শিক্ষামূলক। প্রতিটি README-তে লেখা আছে কোন অংশ Production-এর জন্য যথেষ্ট নয়। কোনো Secret বা আসল Credential এখানে নেই; Demo Token ও Test Token স্পষ্টভাবে চিহ্নিত।
