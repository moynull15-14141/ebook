const add = function (a, b) {
  return a + b;
};

console.log(add(2, 3));
console.log(typeof add);
