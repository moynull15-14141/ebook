const prices = [120, 15, 950];
let total = 0;

for (let i = 0; i < prices.length; i++) {
  total += prices[i];
  console.log(`i=${i} মান=${prices[i]} total=${total}`);
}
